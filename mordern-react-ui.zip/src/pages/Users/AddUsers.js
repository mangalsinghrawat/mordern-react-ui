import React from 'react'

function AddUsers() {
  const [values, setValues] = useState({
    fullname:"",
    username: "",
    email: "",
    DateOfBirth: "",
    password: ""
  });

  return (
    <div>
      
    </div>
  )
}

export default AddUsers