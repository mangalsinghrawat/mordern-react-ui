import axios from "axios"
import { useEffect } from "react"

export const FetchedData = () => {
    useEffect(() => {
       axios
         .get("https://jsonplaceholder.typicode.com/posts")
         .then((res) => {
           console.log(res);
         })
         .catch((error) => {
           console.log(error);
         });
    }, [])
    
}

