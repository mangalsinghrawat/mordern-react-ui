import "./App.css";
import React from "react";
import Register from "../src/pages/RegisterPage/Register.js";
import { Routes, Route } from "react-router-dom";
import Login from "./pages/LoginPage/Login";
import Home from "./pages/HomePage/Home";
import SearchFilter from "./components/SearchFilter";
import Dashboard from "./DashBoard/Dashboard";

function App() {
  return (
    <div className="app">
      <Routes>
        <Route path="/home" element={<Home />} />
        <Route path="/register" element={<Register />} />
        <Route path="/" element={<Login />} />
        <Route path="/login" element={<Login />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path='/users-info' element={<SearchFilter />} />
        {/* {["/", "/login"].map((path, index) => (
          <Route path={path} component={<Login />} key={index} />
        ))} */}
      </Routes>
    </div>
    // <div className="app">
    //   <Dashboard />
    // </div>
    // <div className="app">
    //   <SearchFilter />
    // </div>
  );
}

export default App;
