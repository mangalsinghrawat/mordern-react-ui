import { Button } from "@mui/material";
import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import FormInput from "../../components/FormInput";
import "./Login.css";

function Login() {
  const [values, setValues] = useState({
    username: "",
    password: "",
  });

  const navigate = useNavigate();
  const inputs = [
    {
      id: 1,
      name: "username",
      type: "text",
      placeholder: "Username",
      label: "Username :",
    },
    {
      id: 2,
      name: "password",
      type: "password",
      placeholder: "Password",
      label: "Password : ",
    },
  ];

  var Ousername = "Mangal";
  var Opassword = "123123";

  const handleSubmit = (e) => {
    e.preventDefault();
    if (
      inputs.username === Ousername.value &&
      inputs.password === Opassword.value
    ) {
      navigate("/dashboard");
    } else {
      alert("invalid credentials!");
    }
  };
  const onChange = (e) => {
    setValues({ ...values, [e.target.name]: e.target.value });
  };
  console.log(values);

  // const onChange = (e) => {
  //   setValues({ ...values, [e.target.name]: e.target.value });
  // };
  return (
    <div className="login">
      <form onSubmit={handleSubmit}>
        <h1>Login</h1>
        {inputs.map((input) => (
          <FormInput
            key={input.id}
            {...input}
            value={values[input.name]}
            onChange={onChange}
          />
        ))}
        <Button className="btnSubmit" variant="outlined" type="submit">
          Submit
        </Button>
        <h3 align="center">
          Dont have an Account <Link to="/register">Register</Link>
        </h3>
      </form>
    </div>
  );
}

export default Login;
