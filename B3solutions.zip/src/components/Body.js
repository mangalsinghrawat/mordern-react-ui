import React from "react";

function Body() {
  return (
    <div>
      <h1>This is body of the website </h1>
    </div>
  );
}

export default Body;
